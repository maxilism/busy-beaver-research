"""Check the disjoint all-width proof ledger, not the mathematical certificates themselves."""
from pathlib import Path
import collections, gzip, json
base=Path(__file__).resolve().parent
with gzip.open(base/'marked-potentials.json.gz','rt') as f:marked=set(map(int,json.load(f)))
window6={1309,1505,2135,2207,3129,3269}
uniform6={279,2183,2242,2246,2439,3296}
scan6={399,467,499,2191,2506,2947}
quadratic2={1507,3555}

def classify(r):
    entries=[r>>b & 7 for b in [9,6,3,0]]  # A1, A0, B1, B0
    dest=[e>>2 for e in entries]
    disp=[1-2*(e&1) for e in entries]  # positive inward
    if not (1 in dest[:2] and 0 in dest[2:]):
        # preliminary exclusion applies to this class whenever all reachable cycles
        # within each component have only one sign
        reach_one=(1 not in dest[:2]); s=0 if reach_one else 2
        if disp[s]==disp[s+1]:return 'cycle sign'
        return 'reducible remainder'
    weights=[disp[i] for i in range(4) if dest[i]==i//2]
    weights += [disp[i]+disp[j] for i in (0,1) for j in (2,3) if dest[i]==1 and dest[j]==0]
    if min(weights)>=0 or max(weights)<=0:return 'cycle sign'
    if r in marked:return 'marked potential'
    if any(all((p==u)==(d==1) for p,d in zip(dest,disp)) for u in (0,1)):
        return 'direction-determined calls'
    for S,name in [(uniform6,'six fixed-return rules'),(window6,'six edge-prefix rules'),(scan6,'six edge scans'),(quadratic2,'two zero scans')]:
        if r in S:return name
    raise AssertionError(r)

if __name__=='__main__':
    groups=collections.defaultdict(list)
    for r in range(4096):groups[classify(r)].append(r)
    expected=['wolfram_id\tprimary_upper_bound']+[f'{r}\t{classify(r)}' for r in range(4096)]
    assert (base/'coverage-4096.tsv').read_text().splitlines()==expected
    for name,L in groups.items():print(f'{name}: {len(L)}'+(f' {L}' if len(L)<50 else ''))
    assert sorted(map(len,groups.values()))==[2,6,6,6,28,896,1040,2112]
    assert set(groups['marked potential'])==marked
    after=sorted(sum((L for L in groups.values() if len(L)<50),[]));print('Post-potential complement:',len(after),after)
