"""Small widths, as a COROLLARY of the padded-width-5 theorem, not an unproved timeout."""
# Numbering: a 12-bit rule has octal digits A1,A0,B1,B0 (most to least significant).
# The tape is a nonnegative integer, little-endian from depth 0. No edge padding.

def run(rule, x):
    depth = state = 0  # 0=A, 1=B
    tape = x
    for t in range(1, 126):
        b = (tape >> depth) & 1
        shift = 3 * (2 * (1 - state) + b)
        code = (rule >> shift) & 7
        if (code >> 1) & 1:
            tape |= 1 << depth
        else:
            tape &= ~(1 << depth)
        depth += -1 if code & 1 else 1
        state = code >> 2
        if depth < 0:
            return t
    # Every x<16 is supported in the first FIVE cells, so if the universal
    # n=5 upper bound has been established, no subsequent halt is possible.
    return 0

if __name__ == '__main__':
    best = [-1] * 5
    witnesses = [None] * 5
    for rule in range(4096):
        for x in range(16):
            t = run(rule, x)
            for n in range(x.bit_length(), 5):
                if t > best[n]:
                    best[n] = t
                    witnesses[n] = rule, x
    for n, (t, (rule, x)) in enumerate(zip(best, witnesses)):
        print(f'width {n}: maximum {t}, witnessed by #{rule} on {x}')
    assert best == [7, 17, 31, 49, 71]
