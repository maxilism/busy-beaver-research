# The exact one-sided two-state runtime maximum

© 2026 maxilism · November 24, 2026. Original proof notes, verification code and data in this archive are licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/). Cited third-party works retain their own attribution and terms.

**Theorem (computer-assisted).** Start the head in state A at depth 0, take arbitrary bits at depths $0,\ldots,n-1$ and zeros at every greater depth. Each of the four (state,bit) instructions writes, changes state, and moves one cell. Stop on, and count, the first move from depth 0 to $-1$. Over the halting runs of all 4,096 labeled tables, the maximum for $n\ge5$ is

$$\boxed{4\cdot 2^n-3}.$$

The maximizing rule/input pairs are **#378 and #1351, both on the word of all ones**; the strictness refinement below is needed for this uniqueness claim, not for the numerical maximum. The same conclusions hold for inputs required to have *exactly* $n$ significant bits, since such inputs form a subset and the witnesses still qualify. The full paper-tape convention and rule decoding are in [champion-macros.md](champion-macros.md). Use the four octal digits in order A1,A0,B1,B0, each digit $4q'+2w+e$ with $e=1$ for edgeward; the least-significant input bit sits at the edge. The step count is transitions, not configurations.

**Lower bound.** For #378 or #1351 the first-return excursion at a 0 takes one step, writes 0 and exits in B. At a 1 it makes two identical first-return excursions one position deeper, with three moves of its own, then exits in B with the starting tape restored. Thus $T_0=1$, $T_j=2T_{j-1}+3$ at a run of $j$ leading ones counted from the edge, and $T_j=4\cdot2^j-3$. Take $j=n$. See [the precise local macro](champion-macros.md#exponential-pair-378-and-1351).

**Upper bound.** The disjoint ledger below is reproduced by `python3 coverage.py`; [the full 4,096-ID mapping](coverage-4096.tsv) is also included. Each row gives a proof, not a time cutoff. The broader unmarked-window and uniform-return classifications are optional alternative results and not needed on this route.

|In order; assign each rule to its first matching row|Number of new tables|Proof|
|---|---:|---|
|No reachable strongly connected component with both signs of control cycle|2,112|[Cycle-sign bound](control-graphs.md), including reducible cases|
|Remaining reducible control graphs|896|[One-state rotor after a short transient](control-graphs.md#strengthening-all-reducible-tables), $T\le2n^2+8n+7$|
|Marked local-potential certificate indexed by rule number|1,040|[Potential method](marked-proof.md); [independent replay and strictness](marked-replay.md), [exact rational data](marked-potentials.json.gz)|
|A distinct target state is fixed by each move direction|28|[Local call branching and blank-tail termination](directional-calls.md); only the stated champions can tie|
|279, 2183, 2242, 2246, 2439, 3296|6|[Two barriers](six-barriers.md) and [the four two-letter recurrences](last-four.md)|
|1309, 1505, 2135, 2207, 3129, 3269|6|[Five invariant edge blocks and one bounded descent](six-edge-prefix.md); the small block checks in `six-edge-prefix.py` have no time cutoff|
|399, 467, 499, 2191, 2506, 2947|6|[Six elementary linear-time sweeps](edge-scans.md)|
|1507, 3555|2|[Successive least-zero filling](two-zero-scans.md), $T\le4n^2+2n+1$; see also [a sharper least-zero bound](least-zero-excursions.md)|
|**Total**|**4,096**||

For the largest computer-assisted row, mark cells according to the last rule that wrote them; distinguish never-written input bits from virgin blanks. A finite graph tracks the radius-1 or radius-2 marked head window. Every possible halting computation stays in the intersection of forward-reachable and terminal-reachable windows. Forty of the 1,040 certified tables have no such path. For each remaining table, rational weights make a potential—geometrically weighted marks, with a head-position/window correction—drop by at least one on every surviving transition, including the final edge crossing. Its start-to-terminal difference is at most $4\cdot2^n-3$ for every $n\ge5$. The certificates are **proof data**, rather than trusting a searcher's statement that a feasible LP exists. Replaying them requires only Python's exact rational arithmetic, not an optimization package. The separate equality-edge check shows these 1,040 tables cannot tie, and the other strict rows also cannot tie. Coverage includes all nonhalting behavior without asserting that all computations terminate.

**Reproduction.** In this directory, with Python 3 and assertions enabled:

```sh
python3 marked-replay.py      # frozen rational data, all retained transitions
python3 six-edge-prefix.py    # five short finite-state edge-block inductions
python3 coverage.py           # disjoint partition with the actual uncovered IDs at each named residual row
python3 small-corollary.py    # optional n<5, only after the all-input n=5 proof
```

The case proofs in the table supply the all-width implications of the finite checks. The scripts need only the Python 3 standard library. From the extraction root, `sha256sum -c two-state/proof-manifest.sha256` checks all other files in this archive.

**Small widths.** By the proved padded $n=5$ bound, 125 steps is conclusive for *every* halting run with input less than 16. Direct simulation gives 17, 31, 49, 71 at widths 1,2,3,4 respectively (i.e. $2(n+2)^2-1$), attained by #1447 on all ones. With width 0 interpreted as just the blank tape the maximum is 7. [Exact #1447 formula](champion-macros.md#quadratic-table-1447). No conjectured cutoff or fresh-zero inference is used.

**Priority and scope.** Wolfram's 2002 NKS note on [longest halting times](https://www.wolframscience.com/nks/notes-12-8--longest-halting-times-in-turing-machines/) already states the numeric pattern, and [OEIS A393317](https://oeis.org/A393317) labels the formula conjectural. The proof here is a computer-assisted proof; we do not claim priority for the values, conjecture, or first proof. It concerns the edge-halting one-sided model, not ordinary Busy Beaver halting by a distinguished instruction on a two-way tape. See the [sources and scope](sources.md).
