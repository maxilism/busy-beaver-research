# Local potentials on a marked tape

**Result.** The 1,040 decimal rule IDs in `marked-potentials.json.gz` all obey the bound $T\le 2^{n+2}-3$ for every halting run on every padded $n$-bit input, $n\ge5$. This is an upper bound, not a strict inequality. All are among the 1,088 strongly connected, mixed-cycle-sign rules in `control-graphs.md`. The remaining 48 are identified by `coverage.py`.

**Marks and graph.** Annotate the initially unvisited input by `a` (bit 0) and `b` (bit 1), and the unvisited tail by `t` (bit 0). A written cell instead records one of `0123`: the context $2q+s$ of its most recent write (where $s$ is the scanned bit). Its bit is the bit written by that specific rule. This changes no physical behavior. For the supplied radius $k=1$ or $2$, keep the state and the marked word from head depth $h-k$ through $h+k$, padded on the edge side with `#`. Call this vertex $z$. Besides this finite information, when needed one knows $h$ exactly if $h<k$, or knows $h\ge k$ otherwise.

At the start $h=0$, the state is A, and the window consists of $k$ hashes and $k+1$ fresh input marks ($n\ge5$). Update the center deterministically, shift, and guess the newly visible mark subject to the following constraints. Edge-side cells are all previously written, their last move inward; any hashes form an initial block. On the deeper side all previously written cells form an initial block and their last move was edgeward. These are followed by fresh input, then virgin blank. The center fits in the same written/fresh/virgin ordering as the deeper side, except that its own last write can be of either direction. These assertions follow from nearest-neighbor motion starting at depth 0: one cannot have gone beyond an unvisited cell; to get to the current location from the last departure of *any other* visited cell one must have departed toward it. Shifting across the edge from $h=0$ is a distinct terminal transition. Discard abstract vertices not reachable from the root set or unable to reach a terminal. Every true halting run is still present, including its last transition. Empty surviving graph is itself a certificate.

**Potential.** At a live configuration of depth $h$ and vertex $z$, with marks $l_i$, take

$$P= \sum_{0\le i<h}2^i a_{l_i}+\sum_{i\ge h}2^i b_{l_i}+2^h C_z+U_z+d h.$$

The terminal configuration has $h=-1$, potential $\sum_{i\ge0}2^i b_{l_i}-d$, and no $C,U$ terms. The parameters are rational, with $b_l\ge0$ and $b_t=0$, so all sums exist and terminal potential is at least $-d$. The two arrays $a_l,b_l$ should not be confused with the two initial bit marks `a`,`b`.

For every arc $z\to y$ of displacement $\delta$, old center mark $s$, newly written mark $w$, the difference $P_{new}-P_{old}$ is $2^h L+M$, where

$$L=2^\delta C_y-C_z+\begin{cases}a_w-b_s&\delta=1,\\ b_w-b_s+(b_t-a_t)/2&\delta=-1,\text{ live destination},\\ b_w-b_s&\text{terminal};\end{cases}\qquad M=U_y-U_z+d\delta.$$

Here $t$ in the middle case means the old mark at depth $h-1$, *not necessarily* a virgin blank. Take $C_y=U_y=0$ for a terminal destination. At an exact depth verify $2^h L+M\le-1$. At a window with $h\ge k$, verify $L\le0$ and $2^kL+M\le-1$; these imply the step inequality for every allowable depth. No nonnegativity of the potential along a nonhalting or a halting trajectory is necessary. We telescope only between start and halt.

**Initial calibration.** The arrays have $0\le b_a,b_b\le B\le4$. At each surviving initial window $z$, let $l_0,\ldots,l_k$ be its fresh marks. Verify

$$C_z+U_z+d+\sum_{i=0}^{k}2^i b_{l_i}+(32-2^{k+1})B\le125.$$

This proves $P_{start}+d\le125$ at $n=5$. At larger $n$, the extension of the upper bound is at most $(2^n-32)B\le4(2^n-32)$. Every counted transition decreases $P$ by at least 1, giving $T\le P_{start}-P_{halt}\le P_{start}+d\le4\cdot2^n-3$.

**Artifact.** Gzipped JSON maps rule numbers to `k`, `C_U` (keys: state digit followed by window; value: rational strings $C_z,U_z$), and `a_b_d_B` (arrays $a_l$ then $b_l$ in `0123abt` order, then $d,B$). An empty graph has empty data. The verifier checks the supplied rational coefficients directly; the method used to find them is not a proof premise. Coverage by radius: 914 at $k=1$, 126 more at $k=2$.
