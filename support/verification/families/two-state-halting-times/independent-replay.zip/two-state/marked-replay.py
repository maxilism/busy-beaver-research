'''Independent exact verification of marked rational potential certificates. See accompanying method note.'''
import sys,gzip,json,itertools,collections,hashlib,os
from fractions import Fraction as F
D=os.path.dirname(os.path.abspath(__file__))
if not __debug__: raise RuntimeError('assertions required')
assert hashlib.sha256(open(os.path.join(D,'marked-potentials.json.gz'),'rb').read()).hexdigest()=='71f49b98d7dd75ac7f64735972ea5069633ae7bab9eb9d4133956fbbf3898daa'
R=json.load(gzip.open(os.path.join(D,'marked-potentials.json.gz')))
labels='0123abt'; TERM='H'; zero=F(0); stats=collections.Counter()
def table(n):
    ds=[int(x) for x in format(n,'04o')]
    return [ds[i] for i in [1,0,3,2]]
def getgraph(ds,k):
    toward=''.join(str(c) for c,t in enumerate(ds) if t%2); away=''.join(str(c) for c,t in enumerate(ds) if not t%2)
    roots={'0'+'#'*k+''.join(bits) for bits in itertools.product('ab',repeat=k+1)}
    def succ(z):
        q=int(z[0]);w=z[1:];s=w[k];b= int(s=='b') if s in 'abt' else ds[int(s)]//2%2
        c=q*2+b; tr=ds[c]; movement=1 if tr%2==0 else -1
        v=w[:k]+str(c)+w[k+1:];start=str(tr//4)
        if movement==1:
            last=v[-1]; append= 't' if last=='t' else ('abt' if last in 'ab' else toward+'abt')
            nbrs={start+v[1:]+x for x in append}
        elif v[k-1]=='#': nbrs={TERM}
        else:
            prepend='#' if v[0]=='#' else '#'+away
            nbrs={start+x+v[:-1] for x in prepend}
        return c,movement,nbrs
    edges={}; prev=collections.defaultdict(set);stack=list(roots)
    while stack:
        z=stack.pop()
        if z==TERM or z in edges:continue
        c,h,H=succ(z);edges[z]=(c,h,H)
        for s in H:prev[s].add(z);stack.append(s)
    live=set();stack=[TERM]
    while stack:
        z=stack.pop();
        if z not in live:live.add(z);stack.extend(prev[z])
    live.discard(TERM)
    return roots,edges,live

def audit(n,cert):
    ds=table(n); k=cert['k']; assert k in (1,2); roots,E,live=getgraph(ds,k)
    cu={z:tuple(map(F,t)) for z,t in cert['C_U'].items()};
    if live!=cu.keys():raise ValueError(('states',len(live),len(cu),sorted(live-cu.keys())[:9],sorted(cu.keys()-live)[:9]))
    if not live: assert not cert['a_b_d_B'];stats['nohalt']+=1;return
    v=list(map(F,cert['a_b_d_B']));assert len(v)==16;a=dict(zip(labels,v[:7]));b=dict(zip(labels,v[7:14]));slope=v[14];
    assert min(b.values())>=0 and b['t']==0
    M=max(b['a'],b['b']); assert M<=4
    tight_roots=set(); tight=collections.defaultdict(set)
    for z in roots & live:
        w=z[1+k:]; bound=(2**5-2**(k+1))*M+sum(2**i*b[t] for i,t in enumerate(w))+sum(cu[z])+slope
        if M==4 and bound==125:tight_roots.add(z)
        assert bound<=125,('initial',z,bound)
    cu[TERM]=(zero,zero);stats['states']+=len(live)
    for z in live:
        c,h,H=E[z];w=z[1:];curr=w[k]; C,U=cu[z];
        for y in H:
            if y not in cu:continue
            Cp,Up=cu[y];
            if h==1:
                coeff=C-2*Cp+b[curr]-a[str(c)]
            else:
                coeff=C-Cp/2+b[curr]-b[str(c)]
                if y!=TERM:
                    other=w[k-1];coeff+=(a[other]-b[other])/2
            const=U-Up-slope*h
            min_h=k-w.count('#');
            if '#' not in w and coeff<0:raise ValueError(('slope',z,y,coeff,const))
            delta=2**min_h*coeff+const
            if delta<1: raise ValueError(('decrease',z,y,delta,coeff,const,min_h))
            stats['edges']+=1
            if delta==1 and (y!=TERM or (b[str(c)]==0 and all(b[t]==0 for t in w[k+1:]))):tight[z].add(y)
    seen=set();stack=list(tight_roots)
    while stack:
        z=stack.pop()
        if z not in seen:seen.add(z);stack.extend(tight[z])
    assert TERM not in seen,('possible tie n>5',n)
    if tight_roots:stats['tables_with_tight_roots_for_n>5']+=1
    for inp in range(32):
        q=h=0;x=inp
        for t in range(1,126):
            i=2*q+((x>>h)&1);T=ds[i];q=T//4
            x=x|(1<<h) if T//2%2 else x&~(1<<h)
            h+=1-2*(T%2)
            if h==-1:
                assert t<125, ('n=5 tie',n,inp)
                break

def mixed(n):
    ds=table(n); ends=[t//4 for t in ds]; steps=[1-2*(t%2) for t in ds]
    if 1 not in ends[:2] or 0 not in ends[2:]:return False
    cycles=[steps[c] for c in range(4) if ends[c]==c//2]
    cycles+=[steps[a]+steps[b] for a in (0,1) if ends[a]==1 for b in (2,3) if ends[b]==0]
    return min(cycles)<0<max(cycles)

if __name__=='__main__':
    for ns, cert in R.items(): audit(int(ns),cert)
    ids={int(ns) for ns in R}; mix={n for n in range(4096) if mixed(n)}
    assert len(mix)==1088 and len(ids)==1040 and ids<=mix
    print('Verified',len(ids),'strict exclusions, n>=5;',dict(stats))
    print('Uncovered among mixed-strong:', *sorted(mix-ids))
