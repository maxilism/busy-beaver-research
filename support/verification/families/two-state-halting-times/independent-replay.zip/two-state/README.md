# Independent verification of the two-state maximum

© 2026 maxilism · November 24, 2026. Original proof notes, verification code and data in this archive are licensed under [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/). Cited third-party works retain their own attribution and terms.

**Result.** For the two-state, two-symbol one-sided model with the prescribed conventions, the maximum halting time on padded n-bit inputs is `2^(n+2)−3` for every n≥5. Exactly rules #378 and #1351 attain it, each exactly on the all-ones word. The same maximum and witnesses hold if the MSB must be 1. No priority determination is made here.

**Reproduction.** Extract this archive separately and run `python3 all-replay.py` in its `two-state` directory with assertions enabled. Only the Python standard library is required. The script derives the partition by rule number and compares it with `coverage-4096.tsv` and `all-freeze.json`. It checks the six unmarked-window bounds, verifies the local transitions in the excursion proofs, and invokes the marked rational verifier. The finite tests and the inductions in the notes are both needed. See [sources and scope](sources.md) for prior work.

**Integrity.** The partition and hashes of all script, proof-note and data inputs are in `all-freeze.json` (SHA-256 `d40522ba6e1e6ed59b3281110dd41e4b05a2b1f5babd6a5b5ed7c10360d21336`). The primary companion `proof-bundle.zip` has SHA-256 `6eeaa987639ca67bb65de535feaa3c7bc38a8cd7f0b0f79ec189bb54c6e1b314`; it is not required to run this archive.

**Conventions.** Tape depth is nonnegative into the half-tape, head initially depth 0 in A, LSB at the edge and zeros at all depths ≥n. Octal digits of a rule, high to low, correspond to A1,A0,B1,B0. In `4*next+2*write+dir`, dir=0 increases depth and dir=1 decreases it. The first move to −1 counts and halts.

| Disjoint group in replay order | Number | What gives the all-width result |
|---|---:|---|
| No reachable SCC with cycles of both signs | 2,112 | In strong control, removing cycles bounds prefix depth or remaining displacement by a simple two-state path; in reducible one-signed phases the head scans monotonically. Bound `max(16,2n+3)`; see `control-graphs.md`. |
| Remaining reducibles | 896 | After at most `n+1` steps in transient A, bound one-state final behavior via the last edgeward departure at each cell. In the flipping case local departure counts differ by at most one; net bond crossings give the quadratic bound. `2n²+8n+7` is strict for n≥5. |
| Marked rational potentials | 1,040 | `marked-replay.py` reconstructs live states and unit-or-more rank drops directly from the table: 40 impossible-to-halt tables; 51,345 checked transitions and 20,367 live states for the others. Root and terminal inequalities plus equality-only path check give strictness; see `marked-replay.md`. |
| Distinct direction-determined target states | 28 | Returning activation has ≤2 children. Blank-tail cases and special singular-branch case in `directional-calls.md` bound the total by a binary tree plus no more than the stated blank cost. Equality requires twice-branching calls everywhere down to n, root in inward-entry state A, a restoring A1 two-child call, and all ones. The two possible write bits yield exactly #378 and #1351. The champion inductive call costs solve `T(k)=2T(k−1)+3`, `T(0)=1`, in `champion-macros.md`. |
| Fixed-return residuals | 6 | #279 and #3296: direct permanent barriers (`six-barriers.md`). Four others: transducer child lists recomputed from literal transitions. After first arrival at any level the cell holds 1; initial blank either loses a letter or produces the repeating/consuming words in `last-four.md`. This bounds invocation count by `(n+2)^2`, strictly subtarget. |
| Six windows / edge prefixes | 6 | Five exact first-block exit-mask closures and #1505 descent macros per `six-edge-prefix.md`; independently the unmarked SCC procedure summarized below shows strictness without those macros. |
| Edge scans | 6 | From literal rules (`edge-scans.md`): #467/#499 erase edge ones to zeros; #2506/#2947 flip both bit and state and return after first outward direction; #399 local 1/01/00 macros first advance over zeroed edge prefix and then peel it; #2191 tokens 0/11 advance in velocity and 10 turns to return over ones. Each halter costs ≤`6n+3`. |
| Zero-filling scans | 2 | `two-zero-scans.md`; `least-zero-excursions.md` establishes bounds from a B excursion filling exactly the least zero and restoring the intermediate ones. #1507 tail either goes forever or retreats across edge in B; #3555 alternates root excursions until the first even-indexed zero is filled then exits. Both bounds strictly below target. |

**Separate window calculation.** For each of these six rules the bit-window graph, started in all possible state-A windows, is constructed directly from literal transitions. Mutual reachability identifies SCCs. On each SCC solve maximum adverse displacement for each sign by longest paths with nonnegative starts; a stabilizing sign gives lag B≤3 on these six rules. A halter cannot revisit depth x in this phase with the same complete configuration on the radius-max(B,k) window (k is stored radius): the segment stays in that interval and would repeat. This gives at most `|SCC|·4^max(0,B−k)` visits per depth. For an outward-drifting phase, record increase including the exit is ≤B+1. In an inward-drifting phase each new first-record head beyond the initial tape is on a blank suffix, and the head never retreats more than B from that record in the segment. Repeating the state and B bits just closer to the edge reproduces the intervening segment translated inward forever; on a halter there are ≤2^(B+1) such records, plus at most one exit. Summing these bounds over *all* reachable SCCs gives sufficient per-depth and excess-depth constants c,e. Thus halting depth is <n+e, and time ≤c(n+e). Perform literal exact simulation with these two bounds and full-config repetition as rigorous nonhalt criteria up to the first width n0 where the linear bound is strictly below target. Strictness persists thereafter since `c(n+1+e)≤2c(n+e)` while the target at n+1 exceeds twice that at n.

| ID | c | e | n0 |
|---:|---:|---:|---:|
|1309|102|36|11|
|1505|216|140|14|
|2135|216|149|14|
|2207|144|43|11|
|3129|102|36|11|
|3269|208|141|13|

**No gaps:** the eight counts sum to 4,096; the enumeration verifies disjoint literal IDs, not merely agreement of counts. The analytic classes above are not heuristic classifications. Bounded trajectory search, empirical champion lists and conjectured nonhalting by timeout are not premises of the conclusion.
