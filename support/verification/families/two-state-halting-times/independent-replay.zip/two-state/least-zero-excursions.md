# Least-zero excursions for #1507 and #3555

Assume padded width n≥5, zero blank, A at depth 0, and count the move to −1. With printed high-to-low octal order A1,A0,B1,B0 these rules are `2743` and `6743`, respectively. In both rules A0→1EB, B0→1EA, B1→0IB; their only difference is A1→1IA for #1507 versus A1→1IB for #3555.

**Shared restoring excursion.** Suppose the *least* zero of the current tape is at z, and B is at p≤z. Write g=z−p. Exactly g inward B1 steps replace depths p through z−1 by zeroes. B0 at z writes 1, moves edgeward and sets A. Now exactly g successive edgeward steps (A0 or B0) refill the erased zeroes with ones, toggling state each time. The macro took 2g+1 steps and lands at p−1 in A for even g, B for odd g; if p=0, the final move halts instead. It changed only z (to 1). This includes g=0, as well as p=0 and z=0. In particular, any tail claim below uses the *first zero*, not a fixed-distance slot or virgin symbol inferred from a single read.

## #1507: bound 3n²−n−1

Use checkpoints with either state at p≤z. An A sweep across ones from p to z changes none of them. At z, A0 sets 1 and goes edgeward into B at z−1, or halts if z=0. Its entire cost is z−p+1. A B sweep is the shared excursion above. Thus every macro fills just z, the next z (if needed) is the next zero of the original tape, and every landing p is less than the filled z. The stated invariant holds initially and is preserved. All macros with z<n cost at most `sum_{z=0}^{n−1}(2z+1)=n²` in total, even if the last one halts.

If the run still lives at its first blank-tail macro, the least zero is z=n; all depths from n on are still zero. Every subsequent successful macro increments z by one. **An A macro with z≥n starts an infinite run:** after it, at B (p=z−1, least zero z+1) the gap is 2 and p>0. The B excursion now leads to A at z−2 with least zero z+2. This A sweep in turn resets to exactly the preceding B pattern translated inward by two. Thus an even-gap B with p>0 also cannot halt in this tail. If B starts at n with odd gap n−p, its next B is at p−1 with gap (n−p)+2, still odd, unless it just halted. Writing j=0,…,p, its entire time to exit is

`sum_j [2((n+j)−(p−j))+1]=(p+1)(2n+1)`.

For an even-gap B with p=0, the one final excursion has exactly this same time. If the tail was met already at the root then the state was A. Otherwise its p is at most n−2 (the last pre-tail macro filled z≤n−1 and landed at depth ≤z−1). Consequently any halter takes at most

`n²+(n−1)(2n+1)=3n²−n−1`.

At n=5 this is 69<125. Its step increment is 6n+2, smaller than 2^(n+2) for n≥5, as needed for every larger n.

## #3555: exact maximum

If the edge bit is 0, halt at step 1. Otherwise start in A on the edge 1. Its single A1 step leaves that 1 and enters B at p=1. Let z be the least zero, z≥1. Including this A step the B excursion costs `1+2(z−1)+1=2z`; it fills z and lands at the edge in A if z is odd, B if z is even. Thus repeat such activations while z is odd. At the first even zero z, the macro leaves B at the edge; a final restoring excursion at p=0 fills the next original zero y and halts in 2y+1 more steps. Both z and y exist because the input has finite width.

Put k=ceil(n/2). The even zero z is no deeper than 2k; and the zero y following it is no deeper than 2k+1, even if z<n (2k+1 is certainly initially zero). All preceding consumed odd zeroes are a subset of 1,3,…,2k−1, with sum at most k². Thus the halting time is at most

`2k²+2·(2k)+2·(2k+1)+1=2k²+8k+3`.

The input with 1 at each even depth below n and 0 at each odd depth makes all listed odd zeroes occur, z=2k, y=2k+1. Hence the bound is exact on padded width n. At n=5 it is 45<125. For all n≥5 it is also no larger than 3n²−n−1 (use k≤(n+1)/2), so the same strict comparison holds for every n in question. Neither proof uses finite enumeration, step cutoffs, or a conjectured maximum as an assumption.
