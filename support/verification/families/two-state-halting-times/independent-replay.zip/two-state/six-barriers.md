# Six permanent barriers, all input widths

This independently excludes rules `279 819 1843 3171 3296 3299` from all maxima for n≥5 without any potential, code, or large-n extrapolation. Entries below are write/direction/destination, with `I` increasing depth, `E` decreasing it. Input has bits at depths 0 ... n−1 and zeros beyond, starts at depth 0 in A. Count the move to −1.

| Rule | A0 | A1 | B0 | B1 |
|---:|:---|:---|:---|:---|
|279 |0IB|0IA|1EB|1IA|
|819 |0IB|0EA|1EA|1IB|
|1843|0IB|1EA|1EA|1IB|
|3171|0EA|1IB|1EA|0IB|
|3296|1EA|1IB|0IA|0IB|
|3299|1EA|1IB|1EA|0IB|

**Last five.** Every edgeward move ends in A. For each rule there is exactly one symbol `c` on which the A instruction goes inward, and it leaves `c` unchanged (`c=0` in #819/1843; `c=1` in #3171/3296/3299). If the edge initially holds `c`, the head goes inward; each subsequent return to the edge is again in A reading `c`, so no crossing off the tape is possible. On the other edge symbol the machine halts in one step. Thus their maximum is 1 at every width n≥1.

**Rule 279.** Let `k` be the number of initial 1s from the edge, so `0<=k<=n`. A scans over those `k` ones and the first zero, erasing all `k+1` scanned cells, and arrives in B at `k+1`. If this cell holds 0, B moves edgeward and continues edgeward over the just-erased cells to the edge, including the exit, for total `(k+1)+(k+2)=2k+3`. If it holds 1, B goes inward leaving that 1 unchanged. All edgeward moves end in B, so any later return to this same cell again sends the head inward leaving it 1. This is a permanent barrier to ever crossing the edge. Thus the maximum halting time of #279 at width n is exactly `2n+3` (all ones attain it).
