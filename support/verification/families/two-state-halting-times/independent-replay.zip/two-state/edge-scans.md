# Six residual linear-time scan rules

Use the `champion-macros.md` conventions: `I` is inward, `E` edgeward; the head begins at depth 0 in A, and reaching −1 ends the run, counting that move. Columns below are A0,A1,B0,B1 (not the printed octal digit order); entries are write/direction/target. The proofs are for every padded n-bit input, with all depths ≥n initially 0.

|rule|octal|A0|A1|B0|B1|
|----|-----|--|--|--|--|
|399|0617|1IB|0IA|1EB|0EA|
|467|0723|1EB|0IA|1EA|1IA|
|499|0763|1EB|0IA|1EA|1IB|
|2191|4217|1IA|0IB|1EB|0EA|
|2506|4712|1EB|0IB|1IA|0EA|
|2947|5603|1IB|0EB|1EA|0IA|

**467 and 499.** A scans the initial 1s inward, writing 0s. At the first 0 (depth ≤n), A moves edgeward. All nearer cells are now 0s. Both 0 rules move edgeward, so the head immediately returns through the edge. This costs at most 2n+1.

**2506 and 2947.** Each transition switches state, so state equals the initial state exactly at even depth. Both bits flip, and at each fixed depth the two bits dictate opposite directions. Every cell on the initial inward walk is therefore set to move edgeward next time. The walk turns no later than depth n+1 (the initially blank direction alternates from n onward). At its first turn the machine walks straight out. The bound is 2n+3.

**399.** A first scans 1s writing 0s until the initial first zero at depth i≤n. Now regard A on a 0 at j with every nearer cell 0 as a checkpoint. If the next cell is 1, the successive transitions A0,B1,A1 (in order of positions j,j+1,j) give a checkpoint at j+1 and do not touch deeper cells. This phase consists of j−i such triples up to the first checkpoint j whose next cell is 0; j≤n. At that checkpoint the three transitions A0,B0,B1 leave all cells at depths ≤j equal to 0 and land in A at j−1 (or halt if j=0). The same triple thus repeats on the return, once per remaining cell through depth 0. Total i+3(j−i)+3+3j = 6j−2i+3 ≤ 6n+3.

**2191.** At A with only 1s in the nearer prefix and with the head on unprocessed input, process tokens starting at that depth. An initial `0` costs one A0 step (becomes 1); an initial `11` costs four steps A1,B1,A0,A0, restoring `11` and carrying A two places deeper. These tokens preserve the invariant. An initial `10` ends this phase: at its starting depth j, three steps A1,B0,B0 turn `10` to `11` and land in B at j−1 (or halt). The outward prefix was all 1. On return, a pair of 1s, seen from deeper to nearer, costs four steps B1,A1,B0,B0 and sends B two places nearer, touching no still-nearer bit. If only a single 1 at 0 remains, its first B1 step halts. If there is no `10` token, the machine continues inward forever. Otherwise j≤n−1 and the runtime is at most 2j (input tokens) + 3 + 2j (return) ≤4n+3.

All six bounds are strictly below 2^(n+2)−3 for n≥5.