"""Direct finite block check for the five constant-time rows in six-edge-prefix.md."""
def block(rule, k, state, depth, mask):
    seen = set()
    while 0 <= depth < k and (state, depth, mask) not in seen:
        seen.add((state, depth, mask))
        s = (mask >> depth) & 1
        offset = (6,9,0,3)[2*state+s]  # least-significant octal digit = B0
        a = (rule >> offset) & 7
        mask ^= (s ^ ((a >> 1) & 1)) << depth
        state = a >> 2
        depth += 1 - 2*(a & 1)
    return depth, mask, len(seen)

# (rule, block size, invariant mask set, exact halting maximum)
for rule, k, masks, worst in [(1309,3,{3,7},5), (2135,5,{10},7),
                             (2207,3,{3,7},7), (3129,3,{0,4},5), (3269,4,{5},5)]:
    root = [block(rule,k,0,0,m) for m in range(1<<k)]
    assert {m for d,m,t in root if d==k} == masks
    assert max(t for d,m,t in root if d<0) == worst
    for m in masks:
        for q in (0,1):  # after arbitrary successful return from deeper tape
            d, y, _ = block(rule,k,q,k-1,m)
            assert d>=0 and (d!=k or y in masks)
    print(rule, k, sorted(masks), worst)
