# Four exceptional single-edgeward rules: direct bound

For each of **2183, 2242, 2246, 2439** the duration of every halting run on an $n$-bit input is at most $2(n+2)^2-1$ when $n\ge5$. This is strictly less than $2^{n+2}-3$ (check at 5 and use that $(n+3)^2<2(n+2)^2$). For two other residual IDs, #279 has exact maximum $2n+3$ and #3296 has maximum 1; see [six-barriers.md](six-barriers.md).

Use depth increasing inward, with the initial head at cell 0 in A and first $n$ bits arbitrary, the rest zero. $I,E$ mean inward, edgeward. Below a transition is written `write/direction/state`. Columns are A0,A1,B0,B1, although octal digits are printed in order A1,A0,B1,B0.

| rule (octal) | A0 | A1 | B0 | B1 | children for A0,A1,B0,B1 |
|---|---|---|---|---|---|
|2183 (4207)| 1IA | 0IB | 1EB | 0IA | AA, B, ε, A |
|2242 (4302)| 1EA | 0IB | 1IA | 0IA | ε, B, AB, A |
|2246 (4306)| 1EA | 0IB | 1IB | 0IA | ε, B, BB, A |
|2439 (4607)| 1IB | 0IB | 1EB | 0IA | BA, B, ε, A |

An invocation at $i$ enters from $i-1$ in some state $q$, ending at the next move back to $i-1$. Include the initial invocation at 0. Its children are its invocations of $i+1$. The chronological invocation-entry states at cell $i$ form a word $w_i$, initially $w_0=A$. All successful invocations at a given cell finish by the unique edgeward instruction, writing **1** and returning in its prescribed state. Assuming that child calls return, we compute the word of children using this same prescribed return state after each inward departure, resuming on the bit just written in the parent. This gives the last column above; for example in #2439 an A0 first invokes B (writing 1), resumes in B1 (the unique edgeward arrival state is B), invokes A (writing 0), then B0 returns. A halting run consequently obeys the following simple production rule for $w_{i+1}$: process the first letter of $w_i$ starting with the initial bit at cell $i$, and every later letter with bit 1, concatenating their children. Empty stays empty. The number of invocations is $N=\sum_i |w_i|$. Every move is an inward entry to a nonroot invocation or an edgeward completion of an invocation, hence the runtime is $2N-1$.

For bit 1 each letter simply yields its complement $A\leftrightarrow B$. For bit 0 one letter $s$ vanishes and its opposite $e$ yields either $ee$ or $se$, per the table. Thus length grows by at most one per layer; the first $n$ layers $0,\ldots,n-1$ contribute at most $n(n+1)/2$. At depth $n$ let $m=|w_n|$.

* **2183, 2246: $e\to ee$.** A blank layer with leading $e$ retains that leader forever and cannot halt. A lead $s$ vanishes and the remaining word is complemented, so on a halter each blank step reduces the length by 1. Blank layers thus cost $m(m+1)/2$ with $m\le n+1$. This gives $N\le(n+1)^2$.
* **2242, 2439: $e\to se$.** An increase leaves the other letter $s$ first, so the next layer cannot increase, no matter its input bit. Hence $m\le1+\lceil n/2\rceil$. For any tail word $x$, with letterwise complement $\bar x$, blank steps are $sx\to\bar x$ or $ex\to se\bar x\to sx\to\bar x$. In at most three steps one consumes the first letter, at costs summing to at most $k+(k+1)+k=3k+1$ if the current length is $k$. Therefore
  $$N\le \frac{n(n+1)}2 + \frac{3m(m+1)}2+m\le(n+2)^2.$$
  Indeed after substituting $m=1+\lceil n/2\rceil$, the difference from $(n+2)^2$ is $(h^2+3h)/2$ for $n=2h$ and $(h^2+h-6)/2$ for $n=2h+1$, nonnegative for $n\ge5$.

These are exact symbolic implications for halting runs; no nonhalting orbit or infinite input branch needs to be approximated. The displayed transition and child columns are small enough to check by hand.
