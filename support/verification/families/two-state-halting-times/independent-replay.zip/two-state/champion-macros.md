# Exact all-input times of Wolfram #378, #1351 and #1447

## Conventions

Use nonnegative depths on a tape infinite to the **left**; depth 0 is the right edge. Write $I$ for left, deeper (depth $+1$), and $E$ for right, edgeward (depth $-1$). A transition writes, moves and sets the new state; the first transition from depth 0 to $-1$ halts and **is counted**. Start in state $A$ at depth 0. For integer input $x$, depth $i$ stores $(x\mathbin{\gg}i)\bmod2$, so the least significant bit is at the edge and sufficiently deep cells are 0. Thus a padded $n$-bit word gives $0\le x<2^n$; requiring an MSB of 1 gives the same maxima below. The empty/blank input $x=0$ is also unambiguous.

The digit order of a four-digit octal Wolfram/OEIS rule number (most significant first, including leading zero) is $A1,A0,B1,B0$. Digit $4s'+2w+e$ means next state $A$ for $s'=0$ or $B$ for $s'=1$, write $w$, and move $I$ for $e=0$ or $E$ for $e=1$. Below are **write / move / next state** triples in that order:

|decimal (octal)|A1|A0|B1|B0|
|---|---|---|---|---|
|378 (0572)|0IA|0EB|1EB|1IA|
|1351 (2507)|1IA|0EB|0IA|1EB|
|1447 (2647)|1IA|1IB|0IB|1EB|

Sources: [Wolfram p. 1143, program](https://www.wolframscience.com/nks/notes-12-8--one-sided-turing-machines/); [p. 1144, reported champions](https://www.wolframscience.com/nks/notes-12-8--longest-halting-times-in-turing-machines/); [A393317](https://oeis.org/A393317/internal) and [linked Python implementation](https://oeis.org/A393317/a393317.py.txt), functions `build_transition_tables` and `_simulate_one`. The implementation's final `prefix` is the cumulative maximum over bit lengths; it uses a finite step cap, not a proof of nonhalting in all unobserved cases.

## Exponential pair: 378 and 1351

Let $k$ be the number of consecutive 1s at the edge: $k=\nu_2(x+1)$. Both tables halt, restore the input, and take **exactly**
\[
T_k=4\cdot2^k-3.
\]

Prove a local macro. From $A$ at any depth $j$, run until the first step to $j-1$. The macro arrives there in $B$ without lasting tape changes, and costs $T_k$ if there are $k$ consecutive 1s beginning at $j$ and going inward. For $k=0$, the single rule $A0\to0EB$ gives $T_0=1$. For $k>0$, set $b=0$ for #378 and $b=1$ for #1351. The initial 1 becomes $b$ and gives an inward $A$ call. This returns by induction to $B$ at $j$ with the inner tape unchanged. The $Bb$ rule writes $1-b$ and starts an identical second inward $A$ call. On its return $B(1-b)$ writes 1 and exits edgeward in $B$. This proves the macro with $T_k=2T_{k-1}+3$. Apply it at $j=0$.

For $n$ bits, $k\le n$, with equality exactly at $x=2^n-1$. The two tables' exact maximum is therefore $2^{n+2}-3$ and is a **lower bound** on the global maximum. No other-table upper bound is implicit.

## Quadratic table: 1447

Let $k=\nu_2(x+1)$, $d=k+1$, and let $z_0<z_1<\cdots<z_d$ be the first $d+1$ depths $\ge d$ at which the original tape holds a zero. The exact all-input time is
\[
Q(x)=2d+1+2\sum_{j=0}^d z_j - d(d+1).
\]

Indeed, $A$ sweeps across $k$ ones and changes the first zero to 1, entering $B$ at depth $d$ after $d$ steps. Cells $[0,d)$ are now all 1. From $B$ at any $i$, the first excursion to $i-1$ scans inward to the first zero $z\ge i$, turning the intervening 1s to 0s. It turns the zero to 1, retreats across the newly made zeros restoring all 1s, and exits at $i-1$. Net effect: set only depth $z$ to 1; cost $2(z-i)+1$. The entire $B$ phase consists of these excursions at $i=d-j$, $j=0,\dots,d$, which successively fill $z_j$. Summing their costs and adding $d$ gives the formula. In particular, the output is $x$ with its first $k+3$ zeros (counting from the edge) filled.

For $0\le x<2^n$, we have $d\le n+1$, and all original cells from $n+1$ on are blank, hence $z_j\le n+1+j$. The formula gives
\[
Q(x)\le 2d+1+2(d+1)(n+1)\le 2(n+2)^2-1.
\]
The all-ones input has $d=n+1$ and $z_j=n+1+j$, giving equality. This is below the pair's time for $n\ge5$: the difference is already positive at 5, and $2^{n+2}$ grows faster than the quadratic's step increments $4n+10$ throughout that range. For $n=0,1,2,3,4$, #1447 witnesses $7,17,31,49,71$, respectively; proving those are global maxima requires a separate argument.
