import sys, os, hashlib, gzip, json, collections, subprocess
from pathlib import Path
P=Path(__file__).resolve().parent

def rules(n):
    octets=[(n>>s)&7 for s in (9,6,3,0)]
    return tuple((t//4, t//2%2, 1-2*(t%2)) for t in (octets[1],octets[0],octets[3],octets[2]))

def disposition(n,marked):
    tr=rules(n); d=[x[2] for x in tr];ts=[x[0] for x in tr];reachB=1 in ts[:2];sc=reachB and 0 in ts[2:]
    if sc:
        cycles=[d[i] for i in range(4) if ts[i]==i//2]+[d[i]+d[j] for i in (0,1) for j in (2,3) if ts[i]==1 and ts[j]==0]
        mixed=min(cycles)<0<max(cycles)
    else:
        mixed=any({d[c] for c in range(2*q,2*q+2) if ts[c]==q}=={-1,1} for q in (0,1) if q==0 or reachB)
    if not mixed:return 'sign'
    if not sc:return 'reducible'
    if n in marked:return 'marked'
    if all(m==1-2*t for t,w,m in tr) or all(m==2*t-1 for t,w,m in tr):return 'directional'
    if len({t for t,w,m in tr if m<0})==1:return 'fixed'
    if n in {1309,1505,2135,2207,3129,3269}:return 'window'
    if n in {399,467,499,2191,2506,2947}:return 'edge'
    if n in {1507,3555}:return 'zero'
    raise ValueError(('uncovered',n))

def window(n,width):
    # Bound every condensation path by summing over all reachable SCCs.
    k=width//2;tr=rules(n);S=1<<width;N=2*S
    G=[];Ds=[]
    for v in range(N):
        q,w=divmod(v,S); s=(w>>k)&1; q1,t,d=tr[2*q+s];Ds.append(d)
        w^=(s^t)<<k
        if d>0:z=w>>1;other=z+S//2
        else:z=w*2%S;other=z+1
        G.append([q1*S+z,q1*S+other])
    desc=[]
    for v in range(N):
        seen=set();stack=[v]
        while stack:
            z=stack.pop()
            if z not in seen:seen.add(z);stack+=G[z]
        desc.append(seen)
    unassigned=set.union(*desc[:S]); E=C=0;BBB=0
    while unassigned:
        rep=next(iter(unassigned)); grp={v for v in desc[rep] if rep in desc[v]};unassigned-=grp
        options=[]
        for sig in (-1,1):
            # Maximum adverse displacement of any internal path (unbounded if cycle of wrong sign)
            dd={v:0 for v in grp}
            for _ in range(len(grp)):
                nxt=dd.copy()
                for v in grp:
                    for z in G[v]:
                        if z in grp:nxt[z]=max(nxt[z],dd[v]-sig*Ds[v])
                if nxt==dd:
                    B=max(dd.values());options.append((1+(B if sig<0 else 2**(B+1)),len(grp)*4**max(0,B-k),B));break
                dd=nxt
        assert options; e,c,b=min(options,key=lambda t:(t[2],t[0])); E+=e; C+=c;BBB=max(BBB,b)
    assert BBB<=4
    # Select first n0 such that the uniform linear bound is strict continuously thereafter.
    def target(w):return 4*(1<<w)-3
    w=5; counts=collections.Counter()
    while C*(w+E)>=target(w):
        for word in range(1<<w):
            q=h=0;x=word;seen=set();steps=0
            while h>=0 and h<w+E and steps<=C*(w+E):
                state=(q,h,x)
                if state in seen:counts['loop']+=1;break
                seen.add(state);s=(x>>h)&1;q,t,d=tr[2*q+s];x^=(s^t)<<h;h+=d;steps+=1
            else:
                if h<0:assert steps<target(w);counts['halt']+=1
                else:counts['nonhalt by bound']+=1
        w+=1
    return (C,E,BBB,w,dict(counts))

def save():
    marked={int(n) for n in json.load(gzip.open(P/'marked-potentials.json.gz'))}
    classes=collections.defaultdict(list)
    for n in range(4096):classes[disposition(n,marked)].append(n)
    print('class size', {k:len(v) for k,v in classes.items()})
    for k in ('directional','fixed','window','edge','zero'):print(k,classes[k]);
    assert len(marked)==1040 and set(classes['marked'])==marked
    assert classes['fixed']==[279,2183,2242,2246,2439,3296]
    for n,w in zip(classes['window'],(5,7,7,5,5,7)):print(n,window(n,w))
    return classes


def check_transitions(classes):
    # This checks local rules/preconditions cited by handwritten inductions,
    # NOT an automated proof of the inductions.
    def rt(n):return tuple(f'{s}{"I" if d==1 else "E"}{"AB"[q]}' for q,s,d in rules(n))
    translex={279:'0IB 0IA 1EB 1IA',3296:'1EA 1IB 0IA 0IB',399:'1IB 0IA 1EB 0EA',467:'1EB 0IA 1EA 1IA',499:'1EB 0IA 1EA 1IB',2191:'1IA 0IB 1EB 0EA',2506:'1EB 0IB 1IA 0EA',2947:'1IB 0EB 1EA 0IA',1507:'1EB 1IA 1EA 0IB',3555:'1EB 1IB 1EA 0IB'}
    for n,v in translex.items():assert rt(n)==tuple(v.split())
    # Literal child-word table (all successful calls return in same state, leave bit 1).
    for n,spec in {2183:('AA','B','','A'),2242:('','B','AB','A'),2246:('','B','BB','A'),2439:('BA','B','','A')}.items():
        tr=rules(n); ret={q for q,w,d in tr if d==-1};assert len(ret)==1; (ret,)=ret
        for row in range(4):
            q,s=divmod(row,2); kids=''; seen=set()
            while (q,s) not in seen:
                seen.add((q,s));t,s,d=tr[2*q+s]
                if d<0: assert s==1 and kids==spec[row];break
                kids+='AB'[t];q=ret
            else:raise ValueError(n,row)
    # Characterize all direction-determined equality tables; direct filters
    # from two-child nonlinear recurrence on edge-run of ones.
    eq=[]
    for n in classes['directional']:
        tr=rules(n); U=next(q for q,w,d in tr if d>0);V=1-U;t=tr[1][1]
        if U==0 and tr[0]==(V,0,-1) and tr[1]==(U,t,1) and tr[2*V+t]==(U,1-t,1) and tr[2*V+1-t]==(V,1,-1):eq.append(n)
    assert eq==[378,1351]

def check_edge_prefix():
    # Enumerate every reachable first-block mask, then close under both possible
    # incoming states; an outward escape on reentry would invalidate the lemma.
    for n,k,expect in [(1309,3,5),(2135,5,7),(2207,3,7),(3129,3,5),(3269,4,5)]:
        tr=rules(n)
        def local(q,i,x):
            seen=set()
            while 0<=i<k:
                if (q,i,x) in seen:return None
                seen.add((q,i,x));s=(x>>i)&1;q,t,d=tr[2*q+s];x^=(s^t)<<i;i+=d
            return i,x,len(seen)
        R=set(); times=[]
        for x in range(1<<k):
            z=local(0,0,x)
            if z is not None:
                if z[0]<0:times.append(z[2])
                else:R.add(z[1])
        assert max(times)==expect
        for q in (0,1):
            for x in R:
                z=local(q,k-1,x);assert z is None or (z[0]==k and z[1] in R)
    tr=rules(1505)
    for q0,pat,suffix,steps in [(0,'00**','10*',1),(0,'1010','101',9),(1,'010*','010',1),(1,'110*','010',5)]:
        for x0 in range(16):
            if any(ch!='*' and int(ch)!=((x0>>j)&1) for j,ch in enumerate(pat)):continue
            x=x0;q=q0;i=0
            for j in range(steps):
                assert 0<=i<4;s=(x>>i)&1;q,t,d=tr[2*q+s];x^=(s^t)<<i;i+=d
            assert i==-1 and q==1-q0 and all(ch=='*' or int(ch)==((x>>i)&1) for i,ch in enumerate(suffix))

if __name__=='__main__':
    if not __debug__:raise RuntimeError('assertions required')
    classes=save();check_transitions(classes);check_edge_prefix()
    # Compare the two tabulations only after independently deriving the classes.
    with (P/'all-freeze.json').open() as inp:freeze=json.load(inp)
    assert freeze['ids']==classes
    labels={'sign':'cycle sign','reducible':'reducible remainder','marked':'marked potential',
            'directional':'direction-determined calls','fixed':'six fixed-return rules',
            'window':'six edge-prefix rules','edge':'six edge scans','zero':'two zero scans'}
    by_id={i:labels[k] for k,ids in classes.items() for i in ids}
    expect=['wolfram_id\tprimary_upper_bound']+[f'{i}\t{by_id[i]}' for i in range(4096)]
    assert (P/'coverage-4096.tsv').read_text().splitlines()==expect
    for name,digest in freeze['sha256'].items():
        assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
    subprocess.run([sys.executable,str(P/'marked-replay.py')],check=True)
    print('Hashes, arithmetic classification, exact six-window verification, marked replay, and literal macro inputs passed.')
