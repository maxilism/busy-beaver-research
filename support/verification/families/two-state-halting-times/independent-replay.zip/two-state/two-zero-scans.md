# Zero-filling analysis for the last two quadratic scan rules

Wolfram rules #1507 (`2743` octal) and #3555 (`6743` octal) differ only at A1. In depth order (I = deeper, E = nearer), the transitions are

|rule|A0|A1|B0|B1|
|---|---|---|---|---|
|1507|1EB|1IA|1EA|0IB|
|3555|1EB|1IB|1EA|0IB|

We count the edge-crossing move, begin in A at depth 0, and require zero initial bits at depths ≥n, as in `champion-macros.md`.

**Common B macro.** At depth p≥0 in B let z≥p be the first zero at or deeper than p and h=z−p. The machine executes h inward steps on ones, erasing them to zero, then B0 writes 1 and moves edgeward in A. While traversing the h newly made zeroes, both 0 rules write 1, move edgeward, and change state. Thus after 2h+1 steps the machine first arrives at p−1, in A if h is even and B if h is odd (or it halts for p=0). The sole net tape change is filling the zero at z. This applies even for h=0.

**#1507.** At an A checkpoint at depth p, the machine scans inward over h ones without changing them, fills the zero at z and arrives at z−1 in B after h+1 steps (halting when z=0). Together with the B macro this shows inductively that every complete macro fills exactly the *least remaining zero globally*: p never exceeds that zero's depth. Initially p=0; after a macro next p, if nonnegative, is ≤z, strictly before the next remaining zero. Hence after at most n macros the run has either halted or has just reached the start of the tail phase, whose first remaining zero is z=n, with 0≤p≤n. Each of the at most n pre-tail macros processes z≤n−1 and costs ≤2n−1.

In the tail the successive zeros are z,z+1,z+2,…, so a B macro raises the gap h by 2 and moves p one place edgeward. If it starts with odd h, the B state returns repeatedly, until halt. Starting at tail entrance p with odd gap this costs exactly

$$\sum_{j=0}^p[2(n-p+2j)+1]=(p+1)(2n+1).$$

A B with even gap and p=0 halts in 2n+1 steps. All other cases at tail entrance are nonhalting for n≥2. Indeed, after any A macro at a tail zero z≥n the machine is in B at z−1≥1 with gap 2. That B macro returns in A to z−2≥0, where the next zero is z+2. This A-B pattern repeats, now starting two cells deeper. A B with even gap and p>0 first returns in A with nonnegative p and enters the same pattern. Thus every halter for n≥2 costs at most

$$n(2n-1)+(n+1)(2n+1)=4n^2+2n+1.$$

**#3555.** A0 at the edge halts immediately. With a 1 at the edge, A1 enters B at depth 1, keeping the edge 1. The B macro fills the next zero z and returns to depth 0 after 2(z−1)+1 further steps. The return state is A precisely for odd z and is B for even z. Successive A1/inner-B rounds thus fill successive odd zero depths, and then the first even zero depth e≥2; this even zero exists with e≤n+1 when n≥1, since input ends before n. No previously scanned inner B macro changes any other original zero. There are at most n+1 such rounds, each costing 2z≤2(n+1). Upon the first even one, the machine is in B at depth 0. Its next macro halts. The least still-unfilled zero z′ is at most n+2: if e<n then n is untouched, and if e≥n then e+1 is untouched. Hence this last cost is at most 2(n+2)+1. Total runtime is at most

$$2(n+1)^2+2n+5 = 2n^2+6n+7.$$

For n≥5 the latter polynomial is no larger than the former. At n=5 the larger is 111 < 125, and its successive increments are 8n+6 < 2^(n+2) for n≥5 (and thereafter the right side doubles). So both are strictly below 2^(n+2)−3 for all n≥5.
