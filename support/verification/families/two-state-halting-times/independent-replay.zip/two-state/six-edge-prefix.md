# Final six window rows, without window-SCC analysis or finite-n base cases

Use `champion-macros.md` numbering, orientation and step conventions. These direct proofs show strict inequality for all n≥5 for #1309,#1505,#2135,#2207,#3129,#3269.

**Five small edge blocks.** Take the first k cells, starting at depth 0; encode their bits as an integer (LSB = edge). Simulate locally until the first exit of the block or repetition of (state,depth,mask) confined to the block. The following is an explicit finite certificate. Column R is the set of resulting masks at inward block exits of initial runs (state A, depth 0, arbitrary mask). Column T is the maximum time among edgeward exits of these initial runs. In each row, for every mask in R and *either* possible reentry state at depth k−1, the block run loops locally or exits at k with resulting mask again in R; it never exits at −1. The four tests are direct finite transition evaluations: see `six-edge-prefix.py`, with no external data. Thus a run that exits inward even once cannot later halt: between block exit and reentry, no block cell changes. T is the exact greatest halting time on any padded word of n≥5 (k≤5).

|rule|k|R (decimal masks)|T|
|---:|---:|:---|---:|
|1309|3|3,7|5|
|2135|5|10|7|
|2207|3|3,7|7|
|3129|3|0,4|5|
|3269|4|5|5|

**#1505.** The rows A0,A1,B0,B1 are `1EB,1IA,0EA,0IB`. On 1, either state scans inward preserving the state; on 0 it moves edgeward and switches state. Every step in A writes 1, in B writes 0. Let i be the first initial zero depth. If i=0 the machine halts at once. Otherwise A scans through i, and then B, from i−1, scans through the next initial zero j>i. Here j≤n+1. These two scans cost (i+1)+(j−i+2)=j+3; they leave A at depth x=j−1 with cells x,x+1 both 0.

For the rest of the run use the following descent macros; bits are now *strings in increasing depth order*. The four-bit context begins at the current depth x. Each row ends at depth x−1, with the displayed state and context there; `b` is the arbitrary bit at x−1. A `*` is an arbitrary independent bit. For x=0 the last step just halts.

|entry|context at x|states/letters stepped on, until x−1|cost|result at x−1|
|:---|:---|:---|---:|:---|
|A|`00**`|A0|1|B `b10*`|
|A|`1010`|A1 A0 B1 B1 B1 B0 A0 B0 A0|9|B `b101`|
|B|`010*`|B0|1|A `b010`|
|B|`110*`|B1 B1 B0 A0 B0|5|A `b010`|

The displayed contexts close: `b010` is either `00**` or `1010`; `b10*` lies in one of the two B rows. Thus the remaining j descents take at most 9j steps. All runs halt, with T≤10j+3≤10n+13<2^(n+2)−3 for n≥5 (check n=5, then double).
