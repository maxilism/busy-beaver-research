# Cycle signs and reducible control graphs

Depths are `0,1,…` into the tape, with the initial head in state A at 0; crossing to −1 counts as the last step. The input is arbitrary on cells 0 through n−1, with 0 beyond. The conclusions hold whether initial leading zeroes are allowed or not.

## Counting the control graphs

Give an inward edge weight +1 and an edgeward edge weight −1. In a strongly connected graph with no positive cycle, delete closed subwalks in a prefix ending at depth d to see d≤1: the remaining simple path on two vertices has at most one edge. If instead there is no negative cycle, use the suffix from d to −1: its weight −1−d is ≥−1, so d≤0. This applies to every head position before halting (using the edge-crossing transition in the suffix). Runs bounded to depths 0,1 cannot have more than 16 steps: among pre-transition configurations on the two cells, there are 2·2·4=16 choices, all deeper cells constant, and a repetition prevents halting.

With B unreachable, no opposite-signed cycles means A moves monotonically. If both states are reached but the graph is reducible, A has at most one *kind* of self-transition available before irreversibly switching to B. On a halting run the switch must take place within n+1 steps, unless it halts earlier in A: an inward A scan that passes the first initially blank cell in A continues forever. Once switched, a one-signed B can only move monotonically, giving at most n+2 more steps. This justifies the preliminary bound max(16,2n+3).

For the count, select a pair (destination,weight) for each of the four rules A0,A1,B0,B1. There are 256 such control tables and 16 write assignments each. The following integer counts are at the *control table* level; columns split according to whether a reachable SCC has both a strictly positive and a strictly negative cycle:

| Control class | No | Yes |
|---|---:|---:|
| B unreachable (A never switches) |32|32|
| Both reachable but not strongly connected |24|24|
| Strongly connected |76|68|
| Total |132|124|

Sufficient pseudocode: loop over `product([(0,-1),(0,1),(1,-1),(1,1)],repeat=4)` in the stated rule order. If B is unreachable test whether A's two self-edge signs differ. Else if B never switches to A, test whether B's two signs differ. Otherwise enumerate the weights of all self-edges and the sums of weights of one A→B edge and one B→A edge. Test `min(weights)<0<max(weights)`. Do not compare cycles in *different* SCCs. Thus 2112 exclusions are justified, without any claim about the other 1984 from this test alone.

## Strengthening: all reducible tables

**Claim.** For n≥1 every halting run with a reducible control graph takes at most `2n²+8n+7` steps.

If A can never switch to B, start immediately with the one-state argument below. If A can switch but B cannot switch back, the preceding scan argument applies regardless of the rules of B. If the run halts in A the bound is immediate (any self-edge moves monotonically); otherwise it switches by time n+1. At the start of the final one-state phase let h be its head depth and put m=n+1. Then `0≤h≤m` and all cells of depth i≥m are blank: the switch may have written the first initially blank cell at depth n, but none deeper. These assertions also cover a single reachable state without a switch.

We bound the one-state phase. If both symbols move in the same direction, the phase is monotone. Otherwise identify each symbol with its direction (inward or edgeward). On every halting run the last departure from *each* visited cell points edgeward, since otherwise the head would have to cross that cell again before halting. Exhaust the four functions from the two symbols to themselves for the write operation:

* Identity: the head cannot revisit a cell on a halting run (its direction is a function only of its position). It therefore goes straight to the edge.
* Constant inward symbol: a revisited cell has permanent inward direction and so cannot have an edgeward last departure. A halting run again has no revisits.
* Constant edgeward symbol: each cell makes at most one inward departure in the phase. There are no inward departures at depths i≥m: if the blank points edgeward this is immediate; if the blank points inward, the first visit to m from h≤m would start an infinite inward scan. With ≤m inward departures, net displacement −(h+1) gives ≤2m+h+1 steps.
* Flip both symbols: let a_i and b_i count inward and edgeward departures at depth i in the phase, respectively, and a_{−1}=0. Net crossings of the bond between i−1 and i (or halting bond for i=0) give `b_i=a_{i−1}+[i≤h]`. For a visited cell directions alternate ending edgeward, so `a_i=b_i−[initial direction at i is edgeward]`. At unvisited cells both counts are zero. These two relations give `a_i≤i+1` at i<m. If blank points inward then no i≥m is visited on a halting run; if it points edgeward, each visited i≥m satisfies `a_i=a_{i−1}+[i≤h]−1`. Since h≤m and a_{m−1}≤m this implies `a_m≤m, a_{m+1}≤m−1,…`, with a zero staying zero thereafter. Hence `sum_i a_i ≤ m(m+1)/2 + m(m+1)/2 = m(m+1)`. By net displacement the number of steps is `2 sum_i a_i + h+1 ≤ 2m(m+1)+m+1`.

Add ≤m transient steps to get `2m²+4m+1=2n²+8n+7`. This is less than `2^(n+2)−3` at n=5 (97<125); the gap increases thereafter, since `2^(n+2)>4n+10` for n≥5. This excludes the additional 56×16=896 reducible tables that escaped the initial cycle test. **Exactly 68×16=1088 tables remain after these two exclusions**, not necessarily actual maximizers.

## OEIS implementation caveat

The [Python file attached to A393317](https://oeis.org/A393317/a393317.py.txt) starts in A at depth 0 with the least significant bit of x at depth 0, and counts the transition to −1. As printed on 24 Nov 2026, `_simulate_one` in that file returns 0 on a fresh zero at depth>D if the blank dynamics drift forever. For arbitrary allowed parameters, this is unsound when the deeper input is not all blank. Example: rule 2605 (`5055` octal; high-to-low digit order A1,A0,B1,B0), `x=4`, `D=0`: A scans through depths 0 and 1 and, upon reading 1 at 2, moves edgeward in B and halts at step 5. The guard falsely discards it at depth 1. For default D=16, the first potentially affected n is 19, outside the then-listed range 1–18. Correct by checking the whole as-yet-unvisited suffix (in this case `inp >> depth == 0`, with a suitable guard for large shifts). Independently, exhausting the program's step cap does not prove nonhalting. The program prints running maxima over all input widths ≤n, not just width exactly n.
